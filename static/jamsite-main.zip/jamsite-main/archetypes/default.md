---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: true
author: Author Name
---

Post excerpt

# Main heading

post content...
