---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: true
author: Robert M. Laurie
---

## Photo heading

Photo excerpt

![Page photo](https://placehold.it/500/300)

Photo content
