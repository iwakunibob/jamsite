---
title: Photo1
date: 2022-08-29T13:01:14+09:00
draft: true
---

## Heading for pretty dog

Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio culpa, quod maxime consectetur sint autem rerum quae debitis reprehenderit. Perferendis totam voluptas accusantium. Ducimus, sit illo, harum quas consequuntur quisquam soluta vel ut temporibus dignissimos maxime illum. Nobis numquam eaque deleniti quod aut quo explicabo atque alias sed ut, repellat sit quae reiciendis voluptatibus quidem? Amet cumque corrupti repellat aliquam!

dog dog dog dog dog

![Page photo](/hugo-dog.jpg)

