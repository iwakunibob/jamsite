---
title: Hugo Dog
date: 2022-08-29T01:22:46+09:00
draft: true
author: Robert M. Laurie
---

## Hugo the Dog!

Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consequuntur, sunt?

Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio culpa, quod maxime consectetur sint autem rerum quae debitis reprehenderit. Perferendis totam voluptas accusantium. Ducimus, sit illo, harum quas consequuntur quisquam soluta vel ut temporibus dignissimos maxime illum. Nobis numquam eaque deleniti quod aut quo explicabo atque alias sed ut, repellat sit quae reiciendis voluptatibus quidem? Amet cumque corrupti repellat aliquam!


![Hugo the Dog](/hugo-dog.jpg)


