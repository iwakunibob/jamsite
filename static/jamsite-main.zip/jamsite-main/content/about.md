---
title: "About"
date: 2022-08-29T23:50:39+09:00
draft: true
author: Bob
type: topinfo
---

# About JAMsite

Experimenting with hugo by working through a Udemy course.

Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui ipsum ut cumque perspiciatis neque illo error porro autem deserunt sit, commodi debitis laboriosam adipisci. Ipsa, accusamus voluptatibus quo eligendi fuga saepe labore, quia voluptatum iure corrupti doloribus suscipit ipsam nostrum!

Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat, doloribus excepturi saepe tenetur in reprehenderit explicabo, expedita aut dolore possimus magni obcaecati adipisci illo voluptates libero, aperiam exercitationem eveniet?
